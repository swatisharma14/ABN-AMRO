package com.abnamro.apps.referenceandroid

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import org.junit.Rule
import org.junit.Test

class ReferenceAndroidUiTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun whenAppIsLaunchedThenToolbarIsDisplayed() {
        onView(withId(R.id.toolbar)).check(ViewAssertions.matches(isDisplayed()))
    }

    @Test
    fun whenAppIsLaunchedThenCorrectTextIsDisplayed() {
        onView(withText("Hello World!")).check(ViewAssertions.matches(isDisplayed()))
    }

    @Test
    fun whenAppIsLaunchedThenEmailButtonIsDisplayed() {
        onView(withId(R.id.fab)).check(ViewAssertions.matches(isDisplayed()))
    }

    @Test
    fun whenEmailButtonIsClickedThenCorrectTextIsDisplayed() {
        onView(withId(R.id.fab)).perform(click())
        onView(withText("Replace with your own action")).check(ViewAssertions.matches(isDisplayed()))
    }

}
